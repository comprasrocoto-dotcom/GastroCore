# Arquitectura GastroCore — migración a Supabase multi-marca

_Resumen de lo hecho en esta sesión (11-sep-2026), para Diego y Mariluz._

## Qué encontramos (importante)

El plan original asumía un proyecto de Supabase vacío. **No lo estaba.**

El proyecto `comprasrocoto-dotcom's Project` (`pnotebuwhcuqapynjgrk`) ya tenía
el esquema completo de **una sola marca (Rocoto)**, con datos reales:

| Tabla | Filas | Qué es |
|---|---|---|
| insumos | 471 | Materia prima |
| recetas | 87 | Recetas |
| familias | 18 | Categorías de recetas/insumos |
| Costos Restaurantes | 385 | Tabla sin llave primaria, parece una importación cruda separada de "insumos" — **no se sabe con certeza si el frontend la usa** |
| subfamilias, subrecetas, unidades_medida, configuracion, usuarios, fichas_tecnicas, historial_recetas, precios_historicos, snapshot_detalle, snapshots_semanales | — | Resto del esquema, todas vacías o con datos de Rocoto |

Los IDs de estas tablas son texto tipo Sheets (`FAM-000001`, `INS-000001`,
`REC-000011`...), no UUID. Por eso el plan cambió: en vez de crear tablas
nuevas desde cero, **se extendió lo que ya existía**.

El proyecto también estaba **pausado** (plan gratuito) — se reactivó al
empezar este trabajo.

## Qué se decidió con Mariluz

1. **Unidades de medida son compartidas** entre las 4 marcas (no se les
   agregó marca_id).
2. **Un Admin puede ver varias marcas a la vez** (marca_id = NULL en su
   usuario). Chef y Lector siempre están atados a una sola marca.
3. **El recetario público se sirve una marca a la vez**, por URL
   (`/recetario/[marca]`).
4. La marca de los datos que ya existían se llama **"Rocoto"**.
5. Tablas dudosas ("Costos Restaurantes", precios_historicos,
   snapshot_detalle, snapshots_semanales): se tratan como activas por
   seguridad (se les agrega marca_id igual que al resto) hasta confirmar
   con quien tenga el repo de Next.js si el frontend las usa.

## Qué se preparó (listo para aplicar)

Tres migraciones SQL en `supabase/migrations/`:

- **0001_esquema_multi_marca.sql** — crea la tabla `marcas`, inserta la fila
  "Rocoto", y agrega la columna `marca_id` a las 13 tablas operativas que ya
  existían (con backfill automático: todo lo que ya había pasa a ser de
  Rocoto). También corrige un problema técnico de la tabla "Costos
  Restaurantes" (no tenía llave primaria).
- **0002_rls_multi_marca.sql** — activa Row Level Security en todas esas
  tablas: cada fila solo es visible para su propia marca (o para un Admin
  multi-marca). Es la misma idea de "cada restaurante solo ve lo suyo", pero
  aplicada directamente en la base de datos, no solo en el código.
- **0003_recetario_publico.sql** — crea dos vistas de solo lectura
  (`recetario_publico` y `recetario_publico_ingredientes`) que NO incluyen
  ninguna columna de costo, precio o margen. El endpoint público
  `/recetario/[marca]` debe leer de ahí, nunca de las tablas completas.

**Ninguna de las tres se aplicó todavía.** El sistema bloqueó la ejecución
automática del SQL contra la base de datos de producción como medida de
seguridad — hay que correrlas manualmente desde el SQL Editor de Supabase
(están listas para copiar y pegar) o autorizar explícitamente que se
vuelvan a intentar.

## Qué falta (fuera del alcance de esta sesión)

Esta sesión trabajó **solo del lado de Supabase** — no hubo acceso al
repositorio de Next.js de GastroCore. Falta, siguiendo las fases del plan
original:

- **Fase 3** — reemplazar `lib/api/gastrocore.ts` por una capa que hable
  con Supabase (manteniendo los mismos nombres de función).
- **Fase 4** — cambiar el login para validar contra la tabla `usuarios` de
  Supabase (hoy está vacía y sin columna de contraseña) e incluir
  `marca_id` en la sesión. Para que las políticas RLS funcionen con
  llamadas que no usen la `service_role key`, hay que emitir un JWT con los
  claims `rol`, `marca_id` y `usuario_id` (ver comentario al inicio de
  `0002_rls_multi_marca.sql`).
- **Fase 5** — selector de marca en la UI para el Admin multi-marca.
- **Fase 6** — cambiar la ruta pública a `/recetario/[marca]`.
- **Fase 7** — apagar Apps Script una vez todo esté validado en producción.
- **Confirmar con quien tenga el repo** si "Costos Restaurantes",
  precios_historicos, snapshot_detalle y snapshots_semanales siguen en uso.
- **Definir las otras 3 marcas**: ¿tienen sus propias hojas de Sheets para
  migrar, o arrancan vacías y se cargan manualmente desde la app? El script
  `scripts/migrar-sheets-a-supabase.ts` quedó listo como esqueleto para el
  primer caso.
- **Definir el algoritmo de hash de contraseñas** para `usuarios.clave_hash`
  (no se agregó esa columna todavía porque no se confirmó con qué hash
  validar — hoy el login sigue pasando por Apps Script).
